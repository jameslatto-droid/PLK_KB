import React, { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronRight, RefreshCw, Play, Download } from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RTooltip, Legend,
  ResponsiveContainer, ComposedChart, Area, ReferenceLine
} from "recharts";

/**
 * Sargassum A+B — Project Finance Calculator (React/TSX)
 * --------------------------------------------------------------------
 * Dependencies:
 * - React 18
 * - TailwindCSS (utility classes)
 * - recharts
 * - lucide-react
 * - shadcn/ui (Card, Button) or provide your own replacements
 *
 * Usage:
 *   import ABFinanceCalculator from "./AB_Finance_Calculator";
 *   export default function Page() { return <ABFinanceCalculator/>; }
 */

// ---------------- Formatting helpers ----------------
const f$ = (x: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 })
    .format(Number.isFinite(x) ? x : 0);
const fN = (x: number) =>
  new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 })
    .format(Number.isFinite(x) ? x : 0);
const fP = (x: number) => (Number.isFinite(x) ? (100 * x).toFixed(2) + "%" : "–");

// ---------------- Financial helpers ----------------
function pmt(rate: number, nper: number, pv: number) {
  if (rate === 0) return Math.abs(pv / nper);
  const r = rate;
  return Math.abs((pv * r) / (1 - Math.pow(1 + r, -nper)));
}
function irr(cfs: number[]) {
  // Newton method then bisection fallback
  let guess = 0.15;
  const f = (r: number) => cfs.reduce((a, cf, i) => a + cf / Math.pow(1 + r, i), 0);
  for (let i = 0; i < 50; i++) {
    let npv = 0, der = 0;
    for (let t = 0; t < cfs.length; t++) {
      const d = Math.pow(1 + guess, t);
      npv += cfs[t] / d;
      der += (-t * cfs[t]) / Math.pow(1 + guess, t + 1);
    }
    if (Math.abs(npv) < 1e-7) return guess;
    const step = der !== 0 ? npv / der : 0;
    guess -= step;
    if (guess <= -0.99) { guess = -0.99; break; }
  }
  let lo = -0.99, hi = 1.0;
  let vlo = f(lo), vhi = f(hi);
  for (let i = 0; i < 100; i++) {
    const mid = (lo + hi) / 2, vm = f(mid);
    if (Math.abs(vm) < 1e-7) return mid;
    if (vlo * vm < 0) { hi = mid; vhi = vm; } else { lo = mid; vlo = vm; }
  }
  return NaN;
}
function npv(rate: number, cfs: number[]) {
  return cfs.reduce((a, cf, i) => a + cf / Math.pow(1 + rate, i), 0);
}

// ---------------- Defaults (Barbados-like) ----------------
const DEFAULTS = {
  tpd: 200, days: 275, fee: 100,
  energyMode: "mwxh" as "mwxh" | "mwh", mwh: 24000, powerMW: 3, hoursPerYear: 8000, price: 150,
  varT: 20, varE: 10, fixO: 1200000,
  opexInfl: 0.03, feeEsc: 0.03,
  capex: 25000000, debtPct: 0.65, rate: 0.095, tenor: 15,
  tax: 0.09, depLife: 15, ops: 15,
  licSrv: 0.05, licEn: 0.05,
  successFee: 500000, disc: 0.12,
  dsraMonths: 6,
  finderMode: "capex" as "capex" | "success" | "none", finderPct: 0.01,
  // WTP
  wtp_beachKm: 10, wtp_badDays: 120, wtp_rooms: 1000, wtp_adr: 250, wtp_occHit: 0.10, wtp_sandAnnual: 500000, wtp_retainerShare: 0.5,
};
type Inp = typeof DEFAULTS;

// ---------------- Compute model ----------------
function compute(inp: Inp) {
  const mwhEff = inp.energyMode === "mwxh" ? inp.powerMW * inp.hoursPerYear : inp.mwh;
  const tpy = inp.tpd * inp.days;
  const service0 = tpy * inp.fee;
  const energy0 = mwhEff * inp.price;
  const debt = inp.capex * inp.debtPct;
  const equity = inp.capex - debt;
  const annuity = pmt(inp.rate, inp.tenor, debt);
  const depreciation = inp.capex / inp.depLife;
  const years = Array.from({ length: inp.ops }, (_, i) => i + 1);

  const finderAmt = inp.finderMode === "capex" ? inp.finderPct * inp.capex
    : inp.finderMode === "success" ? inp.finderPct * inp.successFee : 0;

  let opening = debt;
  const rows = years.map(y => {
    const gO = Math.pow(1 + inp.opexInfl, y - 1);
    const gF = Math.pow(1 + inp.feeEsc, y - 1);
    const service = service0 * gF;
    const energy = energy0; // tariff flat unless we add escalation later
    const varT = tpy * inp.varT * gO;
    const varE = mwhEff * inp.varE * gO;
    const fix = inp.fixO * gO;
    const licence = (service - varT) * inp.licSrv + (energy - varE) * inp.licEn; // on gross margins
    const ebitda = service + energy - (varT + varE + fix + licence);

    const interest = (y <= inp.tenor) ? opening * inp.rate : 0;
    const payment = (y <= inp.tenor) ? annuity : 0;
    const principal = (y <= inp.tenor) ? (payment - interest) : 0;
    const success = (y === 1 ? inp.successFee : 0);
    const finder = (y === 1 ? finderAmt : 0);

    const ebt = ebitda - depreciation - interest - success - finder;
    const tax = Math.max(0, ebt * inp.tax);
    const ni = ebt - tax;
    const cfe = ni + depreciation - principal; // cash to equity

    const row = {
      y, service, energy, total: service + energy, varT, varE, fix, licence, ebitda,
      dep: depreciation, interest, payment, principal, success, finder, ebt, tax, ni,
      open: opening, close: Math.max(0, opening - principal), cfe
    };
    opening = row.close; return row;
  });

  // Equity metrics
  const cfs = [-equity, ...rows.map(r => r.cfe)];
  let acc = -equity; const cum = rows.map(r => acc += r.cfe);
  const payIdx = cum.findIndex(v => v >= 0);
  const payback = payIdx >= 0 ? payIdx + 1 : NaN;
  const eqNPV = npv(inp.disc, cfs);
  const eqIRR = irr(cfs);
  const y1 = rows[0];
  const dscr = y1 ? y1.ebitda / annuity : NaN;

  // WTP computed clean cost proxy
  const km = Math.max(1, inp.wtp_beachKm);
  const days = Math.max(1, inp.days);
  const cleanCostPerKmDay = ((inp.varT * inp.tpd) + (inp.fixO / days)) / km;
  const avoidedClean = inp.wtp_beachKm * inp.wtp_badDays * cleanCostPerKmDay;
  const tourismLoss = inp.wtp_rooms * inp.wtp_adr * inp.wtp_occHit * inp.wtp_badDays;
  const targetWTP = avoidedClean + inp.wtp_sandAnnual + tourismLoss;
  const wtpRetainer = targetWTP * inp.wtp_retainerShare;
  const wtpVarPerT = (targetWTP - wtpRetainer) / Math.max(1, tpy);

  // Quarterly (first 8 qtrs, illustrative using Y1 cadence)
  const qPay = annuity / 4, qRate = inp.rate / 4; let qOpen = debt;
  const quarters = Array.from({ length: 8 }, (_, i) => {
    const interest = qOpen * qRate; const principal = qPay - interest; qOpen = Math.max(0, qOpen - principal);
    return {
      q: i + 1, debtService: qPay, interest, principal, close: qOpen,
      service: y1 ? y1.service / 4 : 0, energy: y1 ? y1.energy / 4 : 0
    };
  });

  return {
    rows, years, annuity, debt, equity, mwhEff, tpy,
    cumY0: [-equity, ...cum], debtY0: [debt, ...rows.map(r => r.close)], dscr, eqNPV, eqIRR, payback,
    wtp: { cleanCostPerKmDay, avoidedClean, tourismLoss, targetWTP, wtpRetainer, wtpVarPerT }, quarters
  };
}

// ---------------- UI bits ----------------
function Section({ title, open, setOpen, children }: {
  title: string; open: boolean; setOpen: (b: boolean) => void; children: React.ReactNode;
}) {
  return (
    <Card className="bg-[#121a2b] border-[#1b2640]">
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#1b2640]">
        <h2 className="text-sm text-white font-semibold">{title}</h2>
        <Button variant="outline" className="h-8 px-2 text-xs border-[#2d3e68] bg-[#1d2a4a] text-white"
          onClick={() => setOpen(!open)}>
          {open ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          <span className="ml-1">{open ? "Hide" : "Show"}</span>
        </Button>
      </div>
      {open && <div className="p-4">{children}</div>}
    </Card>
  );
}
function InputRow({ label, tip, children }: { label: string; tip?: string; children: React.ReactNode; }) {
  return (
    <label title={tip || ""} className="flex items-center justify-between gap-2 my-1 px-3 py-2 rounded-lg bg-[#223055]">
      <span className="text-[13px] text-white">{label}</span>
      <div className="w-[160px]">{children}</div>
    </label>
  );
}
function Kpi({ t, v }: { t: string; v: string | number; }) {
  return (
    <div className="rounded-xl border border-[#2a385e] bg-[#1b2540] p-3">
      <div className="text-xs text-white">{t}</div>
      <div className="text-lg font-semibold text-white">{v}</div>
    </div>
  );
}

export default function ABFinanceCalculator() {
  const [inp, setInp] = useState<Inp>({ ...DEFAULTS });
  const [open, setOpen] = useState({ inputs: true, steady: true, wtp: true, pl: true, annual: true, qtr: true, charts: true });

  const model = useMemo(() => compute(inp), [inp]);

  const reset = () => setInp({ ...DEFAULTS });

  // Self tests
  const runTests = () => {
    const issues: string[] = [];
    // amortization sums to debt
    const pay = pmt(0.1, 5, 500); // 500 over 5 yrs @10%
    let bal = 500, sumPrin = 0; for (let i = 0; i < 5; i++) { const int = bal * 0.1, prin = pay - int; bal = Math.max(0, bal - prin); sumPrin += prin; }
    if (Math.abs(sumPrin - 500) > 1e-6) issues.push("Amortization does not sum to principal.");
    // IRR sanity
    const irrVal = irr([-100, 60, 60]); if (Math.abs(irrVal - 0.13) > 0.02) issues.push("IRR sanity check off.");
    // Escalations
    const y2Fix = DEFAULTS.fixO * (1 + DEFAULTS.opexInfl); if (Math.abs(y2Fix - DEFAULTS.fixO * 1.03) > 1e-6) issues.push("OPEX inflation failed.");
    const tpy = DEFAULTS.tpd * DEFAULTS.days; const y2Svc = tpy * DEFAULTS.fee * (1 + DEFAULTS.feeEsc); if (!(y2Svc > tpy * DEFAULTS.fee)) issues.push("Service fee escalation failed.");
    alert(issues.length ? `Self-tests: ${issues.length} issue(s)\n- ` + issues.join("\n- ") : "Self-tests: all passed.");
  };

  // CSV export (Annual summary subset)
  const exportCSV = () => {
    const head = ["Metric", "Year 0", ...model.years.map(y => `Year ${y}`)];
    const rows = [
      ["Service revenue", "", ...model.rows.map(r => r.service)],
      ["Energy revenue", "", ...model.rows.map(r => r.energy)],
      ["Total revenue", "", ...model.rows.map(r => r.total)],
      ["Debt service (annuity)", "", ...model.rows.map(r => r.payment)],
      ["Interest", "", ...model.rows.map(r => r.interest)],
      ["Principal", "", ...model.rows.map(r => r.principal)],
      ["Debt balance (closing)", "", ...model.rows.map(r => r.close)],
      ["EBITDA", "", ...model.rows.map(r => r.ebitda)],
      ["Depreciation", "", ...model.rows.map(r => r.dep)],
      ["Net income", "", ...model.rows.map(r => r.ni)],
      ["Cash to Equity (NI + Dep - Principal)", "", ...model.rows.map(r => r.ni + r.dep - r.principal)],
      ["Cumulative Cash to Equity", -model.equity, ...model.cumY0.slice(1)],
      ["Electricity supplied (MWh)", "", ...model.rows.map(_ => model.mwhEff)],
      ["Electricity sales revenue", "", ...model.rows.map(r => r.energy)],
    ];
    const csv = [head, ...rows]
      .map(r => r.map(v => typeof v === "number" ? Math.round(v).toString() : String(v)).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "annual_summary.csv"; a.click(); URL.revokeObjectURL(url);
  };

  const energyMWh = model.mwhEff;

  return (
    <div className="max-w-[1280px] mx-auto px-4 my-6 text-white">
      <h1 className="text-2xl font-semibold">Sargassum A+B — Project Finance Calculator</h1>
      <p className="mb-4 text-white/80">React (TSX) version. Update inputs → instant results. Barbados defaults pre‑loaded. Includes licence & optional finder fees, WTP estimator, annual summary, NPV/IRR & payback, and charts.</p>

      {/* Inputs */}
      <Section title="Inputs (Barbados defaults)" open={open.inputs} setOpen={b => setOpen({ ...open, inputs: b })}>
        <div className="grid md:grid-cols-4 gap-3">
          {/* 1) Sargassum & Electricity */}
          <div>
            <div className="text-sm text-white mb-1">1) Sargassum collection & electricity</div>
            <InputRow label="Throughput (t/day)" tip="Average tonnes collected daily.">
              <input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number"
                value={inp.tpd} onChange={e => setInp({ ...inp, tpd: +e.target.value })} />
            </InputRow>
            <InputRow label="Operating days/yr" tip="Days per year for collection.">
              <input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number"
                value={inp.days} onChange={e => setInp({ ...inp, days: +e.target.value })} />
            </InputRow>
            <InputRow label="Service fee $/t" tip="Charged per tonne collected.">
              <input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.01}
                value={inp.fee} onChange={e => setInp({ ...inp, fee: +e.target.value })} />
            </InputRow>
            <InputRow label="Energy input mode" tip="Enter MWh/yr or MW×hours">
              <select className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" value={inp.energyMode}
                onChange={e => setInp({ ...inp, energyMode: e.target.value as any })}>
                <option value="mwh">MWh</option>
                <option value="mwxh">MW×hours</option>
              </select>
            </InputRow>
            {inp.energyMode === "mwh" ? (
              <InputRow label="Energy (MWh/yr)">
                <input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number"
                  value={inp.mwh} onChange={e => setInp({ ...inp, mwh: +e.target.value })} />
              </InputRow>
            ) : (
              <>
                <InputRow label="Power (MW)">
                  <input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.1}
                    value={inp.powerMW} onChange={e => setInp({ ...inp, powerMW: +e.target.value })} />
                </InputRow>
                <InputRow label="Operating hours per year">
                  <input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number"
                    value={inp.hoursPerYear} onChange={e => setInp({ ...inp, hoursPerYear: +e.target.value })} />
                </InputRow>
              </>
            )}
            <InputRow label="Energy price $/MWh">
              <input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.01}
                value={inp.price} onChange={e => setInp({ ...inp, price: +e.target.value })} />
            </InputRow>
          </div>

          {/* 2a) CAPEX / OPEX */}
          <div>
            <div className="text-sm text-white mb-1">2a) CAPEX / OPEX</div>
            <InputRow label="Variable OPEX $/t"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.01} value={inp.varT} onChange={e => setInp({ ...inp, varT: +e.target.value })} /></InputRow>
            <InputRow label="Variable OPEX $/MWh"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.01} value={inp.varE} onChange={e => setInp({ ...inp, varE: +e.target.value })} /></InputRow>
            <InputRow label="Fixed OPEX/yr"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.fixO} onChange={e => setInp({ ...inp, fixO: +e.target.value })} /></InputRow>
            <InputRow label="OPEX inflation (p.a.)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={inp.opexInfl} onChange={e => setInp({ ...inp, opexInfl: +e.target.value })} /></InputRow>
            <InputRow label="Service fee escalation (p.a.)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={inp.feeEsc} onChange={e => setInp({ ...inp, feeEsc: +e.target.value })} /></InputRow>
            <InputRow label="CAPEX"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.capex} onChange={e => setInp({ ...inp, capex: +e.target.value })} /></InputRow>
            <InputRow label="Depreciation life (yrs)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.depLife} onChange={e => setInp({ ...inp, depLife: +e.target.value })} /></InputRow>
          </div>

          {/* 2b) Debt / Equity */}
          <div>
            <div className="text-sm text-white mb-1">2b) Debt / Equity</div>
            <InputRow label="Debt % of CAPEX"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={inp.debtPct} onChange={e => setInp({ ...inp, debtPct: +e.target.value })} /></InputRow>
            <InputRow label="Debt rate (p.a.)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={inp.rate} onChange={e => setInp({ ...inp, rate: +e.target.value })} /></InputRow>
            <InputRow label="Debt tenor (yrs)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.tenor} onChange={e => setInp({ ...inp, tenor: +e.target.value })} /></InputRow>
            <InputRow label="Corporate tax rate"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={inp.tax} onChange={e => setInp({ ...inp, tax: +e.target.value })} /></InputRow>
            <InputRow label="Ops years (horizon)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.ops} onChange={e => setInp({ ...inp, ops: +e.target.value })} /></InputRow>
            <InputRow label="Equity discount rate"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={inp.disc} onChange={e => setInp({ ...inp, disc: +e.target.value })} /></InputRow>
            <InputRow label="DSRA months of debt service"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.dsraMonths} onChange={e => setInp({ ...inp, dsraMonths: +e.target.value })} /></InputRow>
          </div>

          {/* 3) Licence & Finder */}
          <div>
            <div className="text-sm text-white mb-1">3) Licence & finder fees</div>
            <InputRow label="Licence % on Service GM"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={inp.licSrv} onChange={e => setInp({ ...inp, licSrv: +e.target.value })} /></InputRow>
            <InputRow label="Licence % on Energy GM"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={inp.licEn} onChange={e => setInp({ ...inp, licEn: +e.target.value })} /></InputRow>
            <InputRow label="Success fee (Year 1)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.successFee} onChange={e => setInp({ ...inp, successFee: +e.target.value })} /></InputRow>

            <InputRow label="Finder fee mode">
              <select className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" value={(inp as any).finderMode}
                onChange={e => setInp({ ...inp, finderMode: e.target.value as any })}>
                <option value="capex">% of CAPEX</option>
                <option value="success">% of Success Fee</option>
                <option value="none">None</option>
              </select>
            </InputRow>
            <InputRow label="Finder fee %"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.0001} value={(inp as any).finderPct} onChange={e => setInp({ ...inp, finderPct: +(e.target as HTMLInputElement).value })} /></InputRow>

            <div className="flex gap-2 mt-3 flex-wrap">
              <Button className="bg-[#1d2a4a] border border-[#2d3e68] text-xs text-white" onClick={exportCSV}><Download className="h-4 w-4 mr-1" />Export Annual CSV</Button>
              <Button className="bg-[#1d2a4a] border border-[#2d3e68] text-xs text-white" onClick={reset}><RefreshCw className="h-4 w-4 mr-1" />Reset Defaults</Button>
              <Button className="bg-[#1d2a4a] border border-[#2d3e68] text-xs text-white" onClick={runTests}><Play className="h-4 w-4 mr-1" />Run self‑tests</Button>
            </div>
            <p className="text-xs text-white/70 mt-2">Accounting depreciation life is set to <b>15 years</b> (aligned to debt). <em>Technical life</em> of valorisation assets is expected to be <b>≥ 20 years</b>.</p>
          </div>
        </div>
      </Section>

      {/* Year‑1 Steady State */}
      <Section title="Year‑1 Steady State" open={open.steady} setOpen={b => setOpen({ ...open, steady: b })}>
        <div className="grid md:grid-cols-4 gap-2">
          <Kpi t="Energy (MWh/yr, effective)" v={fN(energyMWh)} />
          <Kpi t="Service revenue (Y1)" v={f$(model.rows[0]?.service || 0)} />
          <Kpi t="Energy revenue (Y1)" v={f$(model.rows[0]?.energy || 0)} />
          <Kpi t="Licence fees (Y1)" v={f$(model.rows[0]?.licence || 0)} />
          <Kpi t="EBITDA (Y1)" v={f$(model.rows[0]?.ebitda || 0)} />
          <Kpi t="Debt amount" v={f$(model.debt)} />
          <Kpi t="Equity amount" v={f$(model.equity)} />
          <Kpi t="Debt service (ann.)" v={f$(model.annuity)} />
          <Kpi t="DSCR (Yr‑1)" v={fP((model.rows[0]?.ebitda || 0) / model.annuity)} />
        </div>
      </Section>

      {/* WTP */}
      <Section title="Willingness‑to‑Pay (Avoided Cost Model)" open={open.wtp} setOpen={b => setOpen({ ...open, wtp: b })}>
        <div className="grid md:grid-cols-3 gap-3">
          <div>
            <InputRow label="Shoreline protected (km)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.1} value={inp.wtp_beachKm} onChange={e => setInp({ ...inp, wtp_beachKm: +e.target.value })} /></InputRow>
            <InputRow label="Bad sargassum days / yr"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.wtp_badDays} onChange={e => setInp({ ...inp, wtp_badDays: +e.target.value })} /></InputRow>
            <InputRow label="Rooms affected (count)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.wtp_rooms} onChange={e => setInp({ ...inp, wtp_rooms: +e.target.value })} /></InputRow>
            <InputRow label="ADR $/room/night"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.wtp_adr} onChange={e => setInp({ ...inp, wtp_adr: +e.target.value })} /></InputRow>
            <InputRow label="Occ. hit on bad days (%)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.001} value={inp.wtp_occHit} onChange={e => setInp({ ...inp, wtp_occHit: +e.target.value })} /></InputRow>
            <InputRow label="Sand top‑up allowance $/yr"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" value={inp.wtp_sandAnnual} onChange={e => setInp({ ...inp, wtp_sandAnnual: +e.target.value })} /></InputRow>
            <InputRow label="Retainer share of fee (%)"><input className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1" type="number" step={0.01} value={inp.wtp_retainerShare} onChange={e => setInp({ ...inp, wtp_retainerShare: +e.target.value })} /></InputRow>
            <InputRow label="Clean cost $/km/day (computed)"><input disabled className="w-full bg-[#0f1728] border border-[#344268] rounded px-2 py-1 opacity-60" value={Math.round(model.wtp.cleanCostPerKmDay)} /></InputRow>
          </div>
          <div className="grid gap-2">
            <Kpi t="Avoided clean cost / yr" v={f$(model.wtp.avoidedClean)} />
            <Kpi t="Avoided tourism loss / yr" v={f$(model.wtp.tourismLoss)} />
            <Kpi t="Sand top‑up / yr" v={f$(inp.wtp_sandAnnual)} />
            <Kpi t="Target WTP revenue / yr" v={f$(model.wtp.targetWTP)} />
          </div>
          <div className="grid gap-2">
            <Kpi t="Suggested retainer / yr" v={f$(model.wtp.wtpRetainer)} />
            <Kpi t="Suggested variable ($/t)" v={f$(model.wtp.wtpVarPerT)} />
            <Kpi t="All‑in equivalent ($/t)" v={f$(model.wtp.targetWTP / Math.max(1, model.tpy))} />
          </div>
        </div>
      </Section>

      {/* Annual Summary table */}
      <Section title="Annual Summary (Debt, Payback, NPV/IRR, Electricity)" open={open.annual} setOpen={b => setOpen({ ...open, annual: b })}>
        <div className="grid md:grid-cols-4 gap-2 mb-3">
          <Kpi t="Payback (yrs)" v={Number.isFinite(model.payback) ? String(model.payback) : "> " + inp.ops} />
          <Kpi t="Equity NPV" v={f$(Math.round(model.eqNPV))} />
          <Kpi t="Equity IRR" v={Number.isNaN(model.eqIRR) ? "–" : (model.eqIRR * 100).toFixed(2) + "%"} />
          <Kpi t="DSCR (Yr‑1)" v={fP((model.rows[0]?.ebitda || 0) / model.annuity)} />
        </div>
        <div className="overflow-auto max-h-[420px]">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-[#16213b]">
              <tr>
                <th className="text-left p-2 border-b border-[#243259]">Metric</th>
                <th className="text-right p-2 border-b border-[#243259]">Year 0 (FC)</th>
                {model.years.map(y => <th key={y} className="text-right p-2 border-b border-[#243259]">Year {y}</th>)}
              </tr>
            </thead>
            <tbody>
              {[
                ["Service revenue", "", ...model.rows.map(r => f$(r.service))],
                ["Energy revenue", "", ...model.rows.map(r => f$(r.energy))],
                ["Total revenue", "", ...model.rows.map(r => f$(r.total))],
                ["Debt service (annuity)", "", ...model.rows.map(r => f$(r.payment))],
                ["Interest (schedule)", "", ...model.rows.map(r => f$(r.interest))],
                ["Principal (schedule)", "", ...model.rows.map(r => f$(r.principal))],
                ["Debt balance (closing)", "", ...model.rows.map(r => f$(r.close))],
                ["EBITDA", "", ...model.rows.map(r => f$(r.ebitda))],
                ["Depreciation", "", ...model.rows.map(r => f$(r.dep))],
                ["Net income", "", ...model.rows.map(r => f$(r.ni))],
                ["Cash to Equity (NI + Dep - Principal)", "", ...model.rows.map(r => f$(r.ni + r.dep - r.principal))],
                ["Cumulative Cash to Equity", f$(-model.equity), ...model.cumY0.slice(1).map(v => f$(v))],
                ["Electricity supplied (MWh)", "", ...model.rows.map(_ => fN(model.mwhEff))],
                ["Electricity sales revenue", "", ...model.rows.map(r => f$(r.energy))],
              ].map((row, i) => (
                <tr key={i} className="odd:bg-[#0e1526]">
                  {row.map((c, j) => <td key={j} className={"p-2 border-b border-[#243259] " + (j ? "text-right" : "text-left")}>{c as any}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Section>

      {/* Charts */}
      <Section title="Financial Charts" open={open.charts} setOpen={b => setOpen({ ...open, charts: b })}>
        <div className="grid md:grid-cols-2 gap-3">
          <Card className="bg-[#121a2b] border-[#1b2640] p-3">
            <div className="text-sm text-white mb-2">Burn & Cash Balances</div>
            <div className="h-64">
              <ResponsiveContainer>
                <ComposedChart data={(() => {
                  const labels = ["Y0", ...model.years.map(y => "Y" + y)];
                  const CFO = [0, ...model.rows.map(r => r.ni + r.dep)];
                  const CFI = [-inp.capex, ...model.years.map(_ => 0)];
                  const CFF = [model.debt + model.equity, ...model.rows.map(r => -r.principal)];
                  const rows = labels.map((l, i) => ({ label: l, CFO: CFO[i] || 0, CFI: CFI[i] || 0, CFF: CFF[i] || 0 }));
                  let cb = 0; return rows.map(r => { const net = r.CFO + r.CFI + r.CFF; cb += net; return { ...r, Net: net, Cash: cb }; });
                })()}>
                  <CartesianGrid stroke="#243259" />
                  <XAxis dataKey="label" stroke="#ffffff" />
                  <YAxis stroke="#ffffff" tickFormatter={(v) => String(Math.round(Number(v) / 1_000_000)) + "M"} />
                  <RTooltip formatter={(v) => f$(Number(v))} />
                  <Legend wrapperStyle={{ color: "#fff" }} />
                  <Bar dataKey="Net" name="Net cash/period" fill="#f1c40f" />
                  <Line dataKey="Cash" name="Cash, end of period" stroke="#77b7ff" dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="bg-[#121a2b] border-[#1b2640] p-3">
            <div className="text-sm text-white mb-2">Revenues & Net Income</div>
            <div className="h-64">
              <ResponsiveContainer>
                <LineChart data={model.rows.map(r => ({ name: "Y" + r.y, Revenues: r.total, COGS: r.varT + r.varE, SGnA: r.fix + r.licence, NI: r.ni }))}>
                  <CartesianGrid stroke="#243259" />
                  <XAxis dataKey="name" stroke="#ffffff" />
                  <YAxis stroke="#ffffff" tickFormatter={(v) => String(Math.round(Number(v) / 1_000_000)) + "M"} />
                  <RTooltip formatter={(v) => f$(Number(v))} />
                  <Legend wrapperStyle={{ color: "#fff" }} />
                  <Line type="monotone" dataKey="Revenues" stroke="#77b7ff" dot={false} />
                  <Line type="monotone" dataKey="COGS" stroke="#e74c3c" dot={false} />
                  <Line type="monotone" dataKey="SGnA" stroke="#f1c40f" dot={false} />
                  <Line type="monotone" dataKey="NI" stroke="#2ecc71" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="bg-[#121a2b] border-[#1b2640] p-3">
            <div className="text-sm text-white mb-2">Cash Flows (Ops / Invest / Finance)</div>
            <div className="h-64">
              <ResponsiveContainer>
                <BarChart data={(() => {
                  const labels = ["Y0", ...model.years.map(y => "Y" + y)];
                  const CFO = [0, ...model.rows.map(r => r.ni + r.dep)];
                  const CFI = [-inp.capex, ...model.years.map(_ => 0)];
                  const CFF = [model.debt + model.equity, ...model.rows.map(r => -r.principal)];
                  return labels.map((l, i) => ({ name: l, Ops: CFO[i] || 0, Invest: CFI[i] || 0, Finance: CFF[i] || 0 }));
                })()}>
                  <CartesianGrid stroke="#243259" />
                  <XAxis dataKey="name" stroke="#ffffff" />
                  <YAxis stroke="#ffffff" tickFormatter={(v) => String(Math.round(Number(v) / 1_000_000)) + "M"} />
                  <RTooltip formatter={(v) => f$(Number(v))} />
                  <Legend wrapperStyle={{ color: "#fff" }} />
                  <Bar dataKey="Ops" fill="#4da3ff" />
                  <Bar dataKey="Invest" fill="#ff9f43" />
                  <Bar dataKey="Finance" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="bg-[#121a2b] border-[#1b2640] p-3">
            <div className="text-sm text-white mb-2">Expenses by Category</div>
            <div className="h-64">
              <ResponsiveContainer>
                <ComposedChart data={model.rows.map(r => ({ name: "Y" + r.y, VarT: r.varT, VarE: r.varE, Fix: r.fix, Licence: r.licence, OneOff: r.success + r.finder }))}>
                  <CartesianGrid stroke="#243259" />
                  <XAxis dataKey="name" stroke="#ffffff" />
                  <YAxis stroke="#ffffff" tickFormatter={(v) => String(Math.round(Number(v) / 1_000_000)) + "M"} />
                  <RTooltip formatter={(v) => f$(Number(v))} />
                  <Legend wrapperStyle={{ color: "#fff" }} />
                  <Bar dataKey="VarT" stackId="a" fill="#4da3ff" />
                  <Bar dataKey="VarE" stackId="a" fill="#60a5fa" />
                  <Bar dataKey="Fix" stackId="a" fill="#a78bfa" />
                  <Bar dataKey="Licence" stackId="a" fill="#f59e0b" />
                  <Bar dataKey="OneOff" stackId="a" fill="#ef4444" />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="bg-[#121a2b] border-[#1b2640] p-3">
            <div className="text-sm text-white mb-2">Payback &amp; Profit (Cumulative Cash to Equity) + Debt</div>
            <div className="h-64">
              <ResponsiveContainer>
                <ComposedChart data={(() => {
                  const labels = ["Y0", ...model.years.map(y => "Y" + y)];
                  return labels.map((l, i) => ({ name: l, Cum: model.cumY0[i] || 0, Debt: model.debtY0[i] || 0 }));
                })()}>
                  <CartesianGrid stroke="#243259" />
                  <XAxis dataKey="name" stroke="#ffffff" />
                  <YAxis stroke="#ffffff" tickFormatter={(v) => String(Math.round(Number(v) / 1_000_000)) + "M"} />
                  <RTooltip formatter={(v) => f$(Number(v))} />
                  <Legend wrapperStyle={{ color: "#fff" }} />
                  <ReferenceLine y={0} stroke="#ffffff" strokeDasharray="3 3" />
                  <Area dataKey="Cum" name="Cumulative cash to equity" fill="#9ae6b433" stroke="#9ae6b4" />
                  <Line dataKey="Debt" name="Debt outstanding" stroke="#f87171" dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      </Section>

      <p className="text-xs text-white/70 mt-3">Note: Depreciation is set to 15 years to align with debt tenor; expected technical life of valorisation assets is ≥ 20 years.</p>
    </div>
  );
}