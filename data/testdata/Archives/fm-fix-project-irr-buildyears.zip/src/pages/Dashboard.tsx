// src/pages/Dashboard.tsx
import React, { useMemo, useState } from 'react'
import KPI from '../components/KPI'
import Help from '../components/Help'
import FinanceToggles from '../components/FinanceToggles'
import PartA from '../components/PartA'
import PartB from '../components/PartB'
import PartC from '../components/PartC'
import { irr, npv, paybackYears, hasBothSigns, buildProjectFlows, sumAligned } from '../utils/finance'
import { BurnChart, RevNetChart, CashFlowChart } from '../components/charts/PartCharts'
import { usePartDatasets, useCombinedDatasets } from '../hooks/useDatasets'
import { saveScenario, listScenarios, loadScenario, deleteScenario } from '../utils/scenario'
import { downloadCSV } from '../utils/csv'

type View = 'main' | 'chartA' | 'chartB' | 'chartC' | 'chartAll'
type Currency = 'USD' | 'MXN'

function clamp01(n:number){ return Math.max(0, Math.min(1, n)) }

function buildDebtScheduleGrace(principal:number, rate:number, tenorYears:number, graceYears:number) {
  const rows: {interest:number; principal:number; service:number; remaining:number}[] = []
  let remaining = principal
  const g = Math.max(0, Math.min(tenorYears, Math.round(graceYears)))
  const n = Math.max(1, Math.round(tenorYears))
  for (let t=1; t<=g; t++) {
    const interest = remaining * rate
    rows.push({ interest, principal: 0, service: interest, remaining })
  }
  const amortYears = n - g
  if (amortYears <= 0) return { rows }
  const r = rate
  const annuity = r === 0 ? remaining / amortYears : remaining * (r * Math.pow(1+r, amortYears)) / (Math.pow(1+r, amortYears) - 1)
  for (let t=1; t<=amortYears; t++) {
    const interest = remaining * r
    const service = annuity
    const principalPay = Math.max(0, service - interest)
    remaining = Math.max(0, remaining - principalPay)
    rows.push({ interest, principal: principalPay, service, remaining })
  }
  return { rows }
}

export default function Dashboard() {
  const [view, setView] = useState<View>('main')

  // Currency + FX
  const [currency, setCurrency] = useState<Currency>('USD')
  const [fxUSD2MXN, setFxUSD2MXN] = useState<number>(18.0)
  const money = (n: number) => {
    const v = currency === 'USD' ? n : n * fxUSD2MXN
    return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(v)
  }
  const [discountRate, setDiscountRate] = useState<number>(0.10)
  const [taxRate, setTaxRate] = useState<number>(0.25)

  // Common inputs (A+B)
  const [occupiedRooms, setOccupiedRooms] = useState<number>(38000)
  const [roomRateUSD, setRoomRateUSD] = useState<number>(1)
  const [splitA, setSplitA] = useState<number>(0.55)
  const [inflation, setInflation] = useState<number>(0.04)

  const shared = useMemo(() => {
    const annualGross = roomRateUSD * occupiedRooms * 365
    const allocA = annualGross * splitA
    const allocB = annualGross * (1 - splitA)
    return { annualGross, allocA, allocB }
  }, [roomRateUSD, occupiedRooms, splitA])

  // Part A inputs
  const [aCapexUSD, setACapexUSD] = useState<number>(18_000_000)
  const [aEquityPct, setAEquityPct] = useState<number>(0.30)
  const [aInterest, setAInterest] = useState<number>(0.12)
  const [aTenor, setATenor] = useState<number>(10)
  const [aGrace, setAGrace] = useState<number>(0)
  const [aBuildYears, setABuildYears] = useState<number>(0)
  const [aDepYears, setADepYears] = useState<number>(10)
  const [aOpexUSD, setAOpexUSD] = useState<number>(1_500_000)

  const a = useMemo(() => {
    const revenue = shared.allocA
    const n = Math.max(1, Math.round(aTenor))
    const eqPct = clamp01(aEquityPct)
    const equity = aCapexUSD * eqPct
    const debtPV = Math.max(0, aCapexUSD - equity)
    const { rows: debtRows } = buildDebtScheduleGrace(debtPV, aInterest, n, aGrace)
    const opexSeries = Array.from({ length: n }, (_, i) => aOpexUSD * Math.pow(1 + inflation, i))
    const depreciation = Array.from({ length: n }, (_, i) => (i < aDepYears ? aCapexUSD / aDepYears : 0))
    const cfadsBeforeDebt = opexSeries.map((ox) => revenue - ox)

    // Project flows respect build years
    const projectFlows = buildProjectFlows(aCapexUSD, aBuildYears, cfadsBeforeDebt)

    // Equity flows (pre-tax for IRR, post-tax alternative already elsewhere)
    const equityPre = eqPct > 0 ? [-equity, ...cfadsBeforeDebt.map((u, i) => u - (debtRows[i]?.service || 0))] : []
    const equityPost: number[] = eqPct > 0 ? [-equity] : []
    for (let i=0;i<n;i++) {
      const ebitda = cfadsBeforeDebt[i]
      const dep = depreciation[i] || 0
      const interest = debtRows[i]?.interest || 0
      const principal = debtRows[i]?.principal || 0
      const ebit = ebitda - dep
      const ebt  = ebit - interest
      const tax  = ebt > 0 ? ebt * taxRate : 0
      const netIncome = ebt - tax
      const cashToEquity = netIncome + dep - principal
      if (eqPct > 0) equityPost.push(cashToEquity)
    }

    return {
      revenue, debtRows, opexSeries, cfadsBeforeDebt,
      cfadsAfterDebtSeries: cfadsBeforeDebt.map((u, i) => u - (debtRows[i]?.service || 0)),
      depreciation,
      projectFlows,
      projectIRR: irr(projectFlows),
      equityIRR: equityPre.length && hasBothSigns(equityPre) ? irr(equityPre) : NaN,
      equityIRRPostTax: equityPost.length && hasBothSigns(equityPost) ? irr(equityPost) : NaN,
      equityFlows: equityPre,
      buildYears: aBuildYears, graceYears: aGrace
    }
  }, [shared.allocA, aCapexUSD, aEquityPct, aInterest, aTenor, aGrace, aBuildYears, aDepYears, aOpexUSD, inflation, taxRate])

  // Part B inputs
  const [bCapexUSD, setBCapexUSD] = useState<number>(22_000_000)
  const [bEquityPct, setBEquityPct] = useState<number>(0.30)
  const [bInterest, setBInterest] = useState<number>(0.12)
  const [bTenor, setBTenor] = useState<number>(10)
  const [bGrace, setBGrace] = useState<number>(0)
  const [bBuildYears, setBBuildYears] = useState<number>(0)
  const [bDepYears, setBDepYears] = useState<number>(10)
  const [bOpexUSD, setBOpexUSD] = useState<number>(1_800_000)
  const [bPowerMW, setBPowerMW] = useState<number>(6)
  const [bTariffUSDkWh, setBTariffUSDkWh] = useState<number>(0.12)

  const b = useMemo(() => {
    const roomRevenue = shared.allocB
    const hoursPerYear = 8760
    const powerRevenue = bPowerMW * 1000 * hoursPerYear * bTariffUSDkWh
    const revenue = roomRevenue + powerRevenue
    const n = Math.max(1, Math.round(bTenor))
    const eqPct = clamp01(bEquityPct)
    const equity = bCapexUSD * eqPct
    const debtPV = Math.max(0, bCapexUSD - equity)
    const { rows: debtRows } = buildDebtScheduleGrace(debtPV, bInterest, n, bGrace)
    const opexSeries = Array.from({ length: n }, (_, i) => bOpexUSD * Math.pow(1 + inflation, i))
    const depreciation = Array.from({ length: n }, (_, i) => (i < bDepYears ? bCapexUSD / bDepYears : 0))
    const cfadsBeforeDebt = opexSeries.map((ox) => revenue - ox)

    const projectFlows = buildProjectFlows(bCapexUSD, bBuildYears, cfadsBeforeDebt)

    const equityPre = eqPct > 0 ? [-equity, ...cfadsBeforeDebt.map((u, i) => u - (debtRows[i]?.service || 0))] : []
    const equityPost: number[] = eqPct > 0 ? [-equity] : []
    for (let i=0;i<n;i++) {
      const ebitda = cfadsBeforeDebt[i]
      const dep = depreciation[i] || 0
      const interest = debtRows[i]?.interest || 0
      const principal = debtRows[i]?.principal || 0
      const ebit = ebitda - dep
      const ebt  = ebit - interest
      const tax  = ebt > 0 ? ebt * taxRate : 0
      const netIncome = ebt - tax
      const cashToEquity = netIncome + dep - principal
      if (eqPct > 0) equityPost.push(cashToEquity)
    }

    return {
      roomRevenue, powerRevenue, revenue, debtRows, opexSeries, cfadsBeforeDebt,
      cfadsAfterDebtSeries: cfadsBeforeDebt.map((u, i) => u - (debtRows[i]?.service || 0)),
      depreciation,
      projectFlows,
      projectIRR: irr(projectFlows),
      equityIRR: equityPre.length && hasBothSigns(equityPre) ? irr(equityPre) : NaN,
      equityIRRPostTax: equityPost.length && hasBothSigns(equityPost) ? irr(equityPost) : NaN,
      equityFlows: equityPre,
      buildYears: bBuildYears, graceYears: bGrace
    }
  }, [shared.allocB, bCapexUSD, bEquityPct, bInterest, bTenor, bGrace, bBuildYears, bDepYears, bOpexUSD, inflation, taxRate, bPowerMW, bTariffUSDkWh])

  // Part C inputs
  const [wasteDay, setWasteDay] = useState<number>(47_000)
  const wasteYear = wasteDay * 365
  const [cCapexUSD, setCCapexUSD] = useState<number>(54_444_444)
  const [cEquityPct, setCEquityPct] = useState<number>(0.30)
  const [cInterest, setCInterest] = useState<number>(0.12)
  const [cTenor, setCTenor] = useState<number>(10)
  const [cGrace, setCGrace] = useState<number>(0)
  const [cBuildYears, setCBuildYears] = useState<number>(0)
  const [cDepYears, setCDepYears] = useState<number>(15)
  const [cOpexUSD, setCOpexUSD] = useState<number>(3_333_333)
  const [cTariffUSDm3, setCTariffUSDm3] = useState<number>(0.80)
  const [cTariffCurUSDm3, setCTariffCurUSDm3] = useState<number>(0.083)

  const c = useMemo(() => {
    const revenueCurrent = cTariffCurUSDm3 * wasteYear
    const revenueTarget = cTariffUSDm3 * wasteYear
    const n = Math.max(1, Math.round(cTenor))
    const eqPct = clamp01(cEquityPct)
    const equity = cCapexUSD * eqPct
    const debtPV = Math.max(0, cCapexUSD - equity)
    const { rows: debtRows } = buildDebtScheduleGrace(debtPV, cInterest, n, cGrace)
    const opexSeries = Array.from({ length: n }, (_, i) => cOpexUSD * Math.pow(1 + inflation, i))
    const depreciation = Array.from({ length: n }, (_, i) => (i < cDepYears ? cCapexUSD / cDepYears : 0))
    const cfadsBeforeDebt_cur = opexSeries.map((ox) => revenueCurrent - ox)
    const cfadsBeforeDebt_tgt = opexSeries.map((ox) => revenueTarget  - ox)

    const projectFlows = buildProjectFlows(cCapexUSD, cBuildYears, cfadsBeforeDebt_tgt)

    const equityPre = eqPct > 0 ? [-equity, ...cfadsBeforeDebt_tgt.map((u, i) => u - (debtRows[i]?.service || 0))] : []
    const equityPost: number[] = eqPct > 0 ? [-equity] : []
    for (let i=0;i<n;i++) {
      const ebitda = cfadsBeforeDebt_tgt[i]
      const dep = depreciation[i] || 0
      const interest = debtRows[i]?.interest || 0
      const principal = debtRows[i]?.principal || 0
      const ebit = ebitda - dep
      const ebt  = ebit - interest
      const tax  = ebt > 0 ? ebt * taxRate : 0
      const netIncome = ebt - tax
      const cashToEquity = netIncome + dep - principal
      if (eqPct > 0) equityPost.push(cashToEquity)
    }

    return {
      revenueCurrent, revenueTarget, debtRows, opexSeries,
      cfadsBeforeDebt_tgt, cfadsAfterDebtSeries_tgt: cfadsBeforeDebt_tgt.map((u, i) => u - (debtRows[i]?.service || 0)),
      depreciation,
      projectFlows,
      projectIRR: irr(projectFlows),
      equityIRR: equityPre.length && hasBothSigns(equityPre) ? irr(equityPre) : NaN,
      equityIRRPostTax: equityPost.length && hasBothSigns(equityPost) ? irr(equityPost) : NaN,
      equityFlows: equityPre,
      buildYears: cBuildYears, graceYears: cGrace
    }
  }, [cTariffCurUSDm3, cTariffUSDm3, cCapexUSD, cEquityPct, cInterest, cTenor, cGrace, cBuildYears, cDepYears, cOpexUSD, inflation, taxRate, wasteYear])

  // Combined datasets (for charts)
  const DS_A = usePartDatasets(aTenor, aCapexUSD, a.buildYears, a.revenue, a.opexSeries, a.debtRows, a.cfadsBeforeDebt)
  const DS_B = usePartDatasets(bTenor, bCapexUSD, b.buildYears, b.revenue, b.opexSeries, b.debtRows, b.cfadsBeforeDebt)
  const DS_C = usePartDatasets(cTenor, cCapexUSD, c.buildYears, c.revenueTarget, c.opexSeries, c.debtRows, c.cfadsBeforeDebt_tgt)

  const DS_ALL = useCombinedDatasets(
    Math.max(aTenor, bTenor, cTenor),
    (y)=> {
      let inv = 0
      const aSlice = (a.buildYears>0) ? -(aCapexUSD/a.buildYears) : -aCapexUSD
      const bSlice = (b.buildYears>0) ? -(bCapexUSD/b.buildYears) : -bCapexUSD
      const cSlice = (c.buildYears>0) ? -(cCapexUSD/c.buildYears) : -cCapexUSD
      if (y === 0) inv += aSlice + bSlice + cSlice
      if (a.buildYears>1 && y>0 && y<a.buildYears) inv += aSlice
      if (b.buildYears>1 && y>0 && y<b.buildYears) inv += bSlice
      if (c.buildYears>1 && y>0 && y<c.buildYears) inv += cSlice
      return inv
    },
    (y)=> (y===0?0: (y<=a.buildYears+aTenor? a.revenue:0) + (y<=b.buildYears+bTenor? b.revenue:0) + (y<=c.buildYears+cTenor? c.revenueTarget:0)),
    (y)=> (y===0?0: (y> a.buildYears && (y- a.buildYears)<=aTenor? a.opexSeries[y- a.buildYears-1]||0:0) +
                   (y> b.buildYears && (y- b.buildYears)<=bTenor? b.opexSeries[y- b.buildYears-1]||0:0) +
                   (y> c.buildYears && (y- c.buildYears)<=cTenor? c.opexSeries[y- c.buildYears-1]||0:0)),
    (y)=> (y===0?0: (y> a.buildYears && (y- a.buildYears)<=aTenor? a.debtRows[y- a.buildYears-1]?.service||0:0) +
                   (y> b.buildYears && (y- b.buildYears)<=bTenor? b.debtRows[y- b.buildYears-1]?.service||0:0) +
                   (y> c.buildYears && (y- c.buildYears)<=cTenor? c.debtRows[y- c.buildYears-1]?.service||0:0)),
    (y)=> (y===0?0: (y> a.buildYears && (y- a.buildYears)<=aTenor? a.cfadsBeforeDebt[y- a.buildYears-1]||0:0) +
                   (y> b.buildYears && (y- b.buildYears)<=bTenor? b.cfadsBeforeDebt[y- b.buildYears-1]||0:0) +
                   (y> c.buildYears && (y- c.buildYears)<=cTenor? c.cfadsBeforeDebt_tgt[y- c.buildYears-1]||0:0)),
    Math.max(a.buildYears, b.buildYears, c.buildYears)
  )

  // Combined (project) flows for IRR/NPV: sum of part flows (investing + operating)
  const combined = useMemo(() => {
    const flowsA = a.projectFlows
    const flowsB = b.projectFlows
    const flowsC = c.projectFlows
    const projectFlows = sumAligned([flowsA, flowsB, flowsC])
    const projectIRR = irr(projectFlows)

    // Useful aggregates for display (unchanged)
    const totalCapex = (aCapexUSD + bCapexUSD + cCapexUSD)
    const N = Math.max(aTenor + a.buildYears, bTenor + b.buildYears, cTenor + c.buildYears)
    const totalCFADSBeforeDebt = a.cfadsBeforeDebt.reduce((p,c)=>p+c,0)+b.cfadsBeforeDebt.reduce((p,c)=>p+c,0)+c.cfadsBeforeDebt_tgt.reduce((p,c)=>p+c,0)
    const ROI = totalCapex > 0 ? ((totalCFADSBeforeDebt - totalCapex) / totalCapex) : Number.NaN

    // equity IRR (levered, pre-tax) kept as before
    const equity0 = (aCapexUSD * clamp01(aEquityPct)) + (bCapexUSD * clamp01(bEquityPct)) + (cCapexUSD * clamp01(cEquityPct))
    const equityCF = [-equity0, ...Array.from({ length: Math.max(a.cfadsAfterDebtSeries.length, b.cfadsAfterDebtSeries.length, c.cfadsAfterDebtSeries_tgt.length) }, (_, i) =>
      (a.cfadsAfterDebtSeries[i]||0) + (b.cfadsAfterDebtSeries[i]||0) + (c.cfadsAfterDebtSeries_tgt[i]||0)
    )]
    const equityIRR = hasBothSigns(equityCF) ? irr(equityCF) : NaN

    return { totalCapex, totalCFADSBeforeDebt, projectFlows, projectIRR, equityIRR, ROI, N }
  }, [a, b, c, aCapexUSD, bCapexUSD, cCapexUSD, aEquityPct, bEquityPct, cEquityPct, aTenor, bTenor, cTenor])

  // Scenarios, exports, and UI omitted here for brevity — keep your last working UI structure.
  // (You can merge this file over your existing Dashboard to update IRR & NPV logic.)

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* ... keep your header and the rest of your UI ... */}
      <main className="pt-20 px-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* NOTE: This is a focused patch — keep the UI from your current Dashboard.
             Just ensure your KPIs use the following for IRR/NPV:
               - For each part: A.projectIRR, B.projectIRR, C.projectIRR
               - For combined: combined.projectIRR and combined.projectFlows for NPV
          */}
        </div>
      </main>
    </div>
  )
}
