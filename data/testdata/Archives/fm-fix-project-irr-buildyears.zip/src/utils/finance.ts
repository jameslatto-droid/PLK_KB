// src/utils/finance.ts
export function hasBothSigns(cashflows: number[]): boolean {
  let hasPos = false, hasNeg = false
  for (const cf of cashflows) {
    if (cf > 0) hasPos = true
    if (cf < 0) hasNeg = true
    if (hasPos && hasNeg) return true
  }
  return false
}

function npvAt(cfs: number[], r: number): number {
  return cfs.reduce((acc, cf, t) => acc + cf / Math.pow(1+r, t), 0)
}

export function irr(cashflows: number[]): number {
  if (!hasBothSigns(cashflows)) return NaN

  let r = 0.1
  for (let iter=0; iter<100; iter++) {
    let f = 0, fp = 0
    for (let t=0; t<cashflows.length; t++) {
      const cf = cashflows[t]
      const denom = Math.pow(1+r, t)
      f += cf / denom
      if (t>0) fp += -t * cf / Math.pow(1+r, t+1)
    }
    if (Math.abs(f) < 1e-10) return r
    if (!isFinite(fp) || fp === 0) break
    const step = f / fp
    let rnext = r - step
    if (!isFinite(rnext) || rnext <= -0.99) rnext = r - 0.5*step
    r = rnext
  }

  // Expand bracket and bisection
  let lo = -0.99
  let hi = 1.0
  let fLo = npvAt(cashflows, lo)
  let fHi = npvAt(cashflows, hi)
  const MAX_HI = 1e6
  while (Math.sign(fLo) === Math.sign(fHi) && hi < MAX_HI) {
    hi *= 2
    fHi = npvAt(cashflows, hi)
  }
  if (Math.sign(fLo) === Math.sign(fHi)) return NaN

  for (let i=0; i<200; i++) {
    const mid = (lo + hi) / 2
    const fMid = npvAt(cashflows, mid)
    if (Math.abs(fMid) < 1e-10) return mid
    if (Math.sign(fMid) === Math.sign(fLo)) { lo = mid; fLo = fMid } else { hi = mid; fHi = fMid }
  }
  return (lo + hi) / 2
}

export function npv(rate: number, cashflows: number[]): number {
  return cashflows.reduce((acc, cf, t) => acc + cf / Math.pow(1+rate, t), 0)
}

export function paybackYears(cashflows: number[]): number {
  let cum = 0
  for (let t=0; t<cashflows.length; t++) {
    const prev = cum
    cum += cashflows[t]
    if (cum >= 0) {
      const cf = cashflows[t]
      const frac = cf !== 0 ? (0 - prev) / cf : 0
      return t - 1 + frac
    }
  }
  return NaN
}

/**
 * Build unlevered "project" cash flows that respect build years.
 * - CAPEX is spread evenly across `buildYears` (or lumped at t=0 if 0).
 * - Operating unlevered CF (CFADS before debt) starts after build period.
 */
export function buildProjectFlows(capex: number, buildYears: number, cfadsBeforeDebt: number[]): number[] {
  const b = Math.max(0, Math.floor(buildYears))
  const flows: number[] = []
  if (b === 0) {
    flows.push(-capex)
  } else {
    const slice = -capex / b
    for (let i=0; i<b; i++) flows.push(slice)
  }
  for (let i=0; i<cfadsBeforeDebt.length; i++) flows.push(cfadsBeforeDebt[i])
  return flows
}

/**
 * Sum arrays element-wise up to max length (padding with 0).
 */
export function sumAligned(arrays: number[][]): number[] {
  const L = Math.max(0, ...arrays.map(a => a.length))
  const out = new Array(L).fill(0)
  for (const a of arrays) {
    for (let i=0; i<a.length; i++) out[i] += a[i]
  }
  return out
}
