// src/pages/Dashboard.tsx
import React, { useMemo, useState } from 'react'
import KPI from '../components/KPI'
import Help from '../components/Help'
import FinanceToggles from '../components/FinanceToggles'
import PartA from '../components/PartA'
import PartB from '../components/PartB'
import PartC from '../components/PartC'
import { irr, npv, paybackYears, hasBothSigns } from '../utils/finance'
import { BurnChart, RevNetChart, CashFlowChart } from '../components/charts/PartCharts'
import { usePartDatasets, useCombinedDatasets } from '../hooks/useDatasets'
import { saveScenario, listScenarios, loadScenario, deleteScenario } from '../utils/scenario'
import { downloadCSV } from '../utils/csv'

type View = 'main' | 'chartA' | 'chartB' | 'chartC' | 'chartAll'
type Currency = 'USD' | 'MXN'

function clamp01(n:number){ return Math.max(0, Math.min(1, n)) }

function buildDebtScheduleGrace(principal:number, rate:number, tenorYears:number, graceYears:number) {
  const rows: {interest:number; principal:number; service:number; remaining:number}[] = []
  let remaining = principal
  const g = Math.max(0, Math.min(tenorYears, Math.round(graceYears)))
  const n = Math.max(1, Math.round(tenorYears))
  for (let t=1; t<=g; t++) {
    const interest = remaining * rate
    rows.push({ interest, principal: 0, service: interest, remaining })
  }
  const amortYears = n - g
  if (amortYears <= 0) return { rows }
  const r = rate
  const annuity = r === 0 ? remaining / amortYears : remaining * (r * Math.pow(1+r, amortYears)) / (Math.pow(1+r, amortYears) - 1)
  for (let t=1; t<=amortYears; t++) {
    const interest = remaining * r
    const service = annuity
    const principalPay = Math.max(0, service - interest)
    remaining = Math.max(0, remaining - principalPay)
    rows.push({ interest, principal: principalPay, service, remaining })
  }
  return { rows }
}

export default function Dashboard() {
  const [view, setView] = useState<View>('main')

  // Currency + FX
  const [currency, setCurrency] = useState<Currency>('USD')
  const [fxUSD2MXN, setFxUSD2MXN] = useState<number>(18.0)
  const money = (n: number) => {
    const v = currency === 'USD' ? n : n * fxUSD2MXN
    return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 0 }).format(v)
  }
  const [discountRate, setDiscountRate] = useState<number>(0.10)
  const [taxRate, setTaxRate] = useState<number>(0.25)

  // Common inputs (A+B)
  const [occupiedRooms, setOccupiedRooms] = useState<number>(38000)
  const [roomRateUSD, setRoomRateUSD] = useState<number>(1)
  const [splitA, setSplitA] = useState<number>(0.55)
  const [inflation, setInflation] = useState<number>(0.04)

  const shared = useMemo(() => {
    const annualGross = roomRateUSD * occupiedRooms * 365
    const allocA = annualGross * splitA
    const allocB = annualGross * (1 - splitA)
    return { annualGross, allocA, allocB }
  }, [roomRateUSD, occupiedRooms, splitA])

  // Part A inputs
  const [aCapexUSD, setACapexUSD] = useState<number>(18_000_000)
  const [aEquityPct, setAEquityPct] = useState<number>(0.30)
  const [aInterest, setAInterest] = useState<number>(0.12)
  const [aTenor, setATenor] = useState<number>(10)
  const [aGrace, setAGrace] = useState<number>(0)
  const [aBuildYears, setABuildYears] = useState<number>(0)
  const [aDepYears, setADepYears] = useState<number>(10)
  const [aOpexUSD, setAOpexUSD] = useState<number>(1_500_000)

  const a = useMemo(() => {
    const revenue = shared.allocA
    const n = Math.max(1, Math.round(aTenor))
    const eqPct = clamp01(aEquityPct)
    const equity = aCapexUSD * eqPct
    const debtPV = Math.max(0, aCapexUSD - equity)
    const { rows: debtRows } = buildDebtScheduleGrace(debtPV, aInterest, n, aGrace)
    const opexSeries = Array.from({ length: n }, (_, i) => aOpexUSD * Math.pow(1 + inflation, i))
    const depreciation = Array.from({ length: n }, (_, i) => (i < aDepYears ? aCapexUSD / aDepYears : 0))
    const cfadsBeforeDebt = opexSeries.map((ox) => revenue - ox)
    const equityPre = equity > 0 ? [-equity, ...cfadsBeforeDebt.map((u, i) => u - (debtRows[i]?.service || 0))] : []
    const equityPost: number[] = equity > 0 ? [-equity] : []
    for (let i=0;i<n;i++) {
      const ebitda = cfadsBeforeDebt[i]
      const dep = depreciation[i] || 0
      const interest = debtRows[i]?.interest || 0
      const principal = debtRows[i]?.principal || 0
      const ebit = ebitda - dep
      const ebt  = ebit - interest
      const tax  = ebt > 0 ? ebt * taxRate : 0
      const netIncome = ebt - tax
      const cashToEquity = netIncome + dep - principal
      if (equity > 0) equityPost.push(cashToEquity)
    }
    const projectFlows = [-aCapexUSD, ...cfadsBeforeDebt]
    return {
      revenue, debtRows, opexSeries, cfadsBeforeDebt,
      cfadsAfterDebtSeries: cfadsBeforeDebt.map((u, i) => u - (debtRows[i]?.service || 0)),
      depreciation,
      projectIRR: irr(projectFlows),
      equityIRR: equityPre.length && hasBothSigns(equityPre) ? irr(equityPre) : NaN,
      equityIRRPostTax: equityPost.length && hasBothSigns(equityPost) ? irr(equityPost) : NaN,
      projectFlows,
      equityFlows: equityPre,
      buildYears: aBuildYears, graceYears: aGrace
    }
  }, [shared.allocA, aCapexUSD, aEquityPct, aInterest, aTenor, aGrace, aBuildYears, aDepYears, aOpexUSD, inflation, taxRate])

  // Part B inputs
  const [bCapexUSD, setBCapexUSD] = useState<number>(22_000_000)
  const [bEquityPct, setBEquityPct] = useState<number>(0.30)
  const [bInterest, setBInterest] = useState<number>(0.12)
  const [bTenor, setBTenor] = useState<number>(10)
  const [bGrace, setBGrace] = useState<number>(0)
  const [bBuildYears, setBBuildYears] = useState<number>(0)
  const [bDepYears, setBDepYears] = useState<number>(10)
  const [bOpexUSD, setBOpexUSD] = useState<number>(1_800_000)
  const [bPowerMW, setBPowerMW] = useState<number>(6)
  const [bTariffUSDkWh, setBTariffUSDkWh] = useState<number>(0.12)

  const b = useMemo(() => {
    const roomRevenue = shared.allocB
    const hoursPerYear = 8760
    const powerRevenue = bPowerMW * 1000 * hoursPerYear * bTariffUSDkWh
    const revenue = roomRevenue + powerRevenue
    const n = Math.max(1, Math.round(bTenor))
    const eqPct = clamp01(bEquityPct)
    const equity = bCapexUSD * eqPct
    const debtPV = Math.max(0, bCapexUSD - equity)
    const { rows: debtRows } = buildDebtScheduleGrace(debtPV, bInterest, n, bGrace)
    const opexSeries = Array.from({ length: n }, (_, i) => bOpexUSD * Math.pow(1 + inflation, i))
    const depreciation = Array.from({ length: n }, (_, i) => (i < bDepYears ? bCapexUSD / bDepYears : 0))
    const cfadsBeforeDebt = opexSeries.map((ox) => revenue - ox)
    const equityPre = equity > 0 ? [-equity, ...cfadsBeforeDebt.map((u, i) => u - (debtRows[i]?.service || 0))] : []
    const equityPost: number[] = equity > 0 ? [-equity] : []
    for (let i=0;i<n;i++) {
      const ebitda = cfadsBeforeDebt[i]
      const dep = depreciation[i] || 0
      const interest = debtRows[i]?.interest || 0
      const principal = debtRows[i]?.principal || 0
      const ebit = ebitda - dep
      const ebt  = ebit - interest
      const tax  = ebt > 0 ? ebt * taxRate : 0
      const netIncome = ebt - tax
      const cashToEquity = netIncome + dep - principal
      if (equity > 0) equityPost.push(cashToEquity)
    }
    const projectFlows = [-bCapexUSD, ...cfadsBeforeDebt]
    return {
      roomRevenue, powerRevenue, revenue, debtRows, opexSeries, cfadsBeforeDebt,
      cfadsAfterDebtSeries: cfadsBeforeDebt.map((u, i) => u - (debtRows[i]?.service || 0)),
      depreciation,
      projectIRR: irr(projectFlows),
      equityIRR: equityPre.length && hasBothSigns(equityPre) ? irr(equityPre) : NaN,
      equityIRRPostTax: equityPost.length && hasBothSigns(equityPost) ? irr(equityPost) : NaN,
      projectFlows,
      equityFlows: equityPre,
      buildYears: bBuildYears, graceYears: bGrace
    }
  }, [shared.allocB, bCapexUSD, bEquityPct, bInterest, bTenor, bGrace, bBuildYears, bDepYears, bOpexUSD, inflation, taxRate, bPowerMW, bTariffUSDkWh])

  // Part C inputs (now includes wastewater capacity)
  const [wasteDay, setWasteDay] = useState<number>(47_000)
  const wasteYear = wasteDay * 365
  const [cCapexUSD, setCCapexUSD] = useState<number>(54_444_444)
  const [cEquityPct, setCEquityPct] = useState<number>(0.30)
  const [cInterest, setCInterest] = useState<number>(0.12)
  const [cTenor, setCTenor] = useState<number>(10)
  const [cGrace, setCGrace] = useState<number>(0)
  const [cBuildYears, setCBuildYears] = useState<number>(0)
  const [cDepYears, setCDepYears] = useState<number>(15)
  const [cOpexUSD, setCOpexUSD] = useState<number>(3_333_333)
  const [cTariffUSDm3, setCTariffUSDm3] = useState<number>(0.80)   // target tariff (slider in PartC)
  const [cTariffCurUSDm3, setCTariffCurUSDm3] = useState<number>(0.083) // current tariff

  const c = useMemo(() => {
    const revenueCurrent = cTariffCurUSDm3 * wasteYear
    const revenueTarget = cTariffUSDm3 * wasteYear
    const n = Math.max(1, Math.round(cTenor))
    const eqPct = clamp01(cEquityPct)
    const equity = cCapexUSD * eqPct
    const debtPV = Math.max(0, cCapexUSD - equity)
    const { rows: debtRows } = buildDebtScheduleGrace(debtPV, cInterest, n, cGrace)
    const opexSeries = Array.from({ length: n }, (_, i) => cOpexUSD * Math.pow(1 + inflation, i))
    const depreciation = Array.from({ length: n }, (_, i) => (i < cDepYears ? cCapexUSD / cDepYears : 0))
    const cfadsBeforeDebt_cur = opexSeries.map((ox) => revenueCurrent - ox)
    const cfadsBeforeDebt_tgt = opexSeries.map((ox) => revenueTarget  - ox)
    const equityPre = equity > 0 ? [-equity, ...cfadsBeforeDebt_tgt.map((u, i) => u - (debtRows[i]?.service || 0))] : []
    const equityPost: number[] = equity > 0 ? [-equity] : []
    for (let i=0;i<n;i++) {
      const ebitda = cfadsBeforeDebt_tgt[i]
      const dep = depreciation[i] || 0
      const interest = debtRows[i]?.interest || 0
      const principal = debtRows[i]?.principal || 0
      const ebit = ebitda - dep
      const ebt  = ebit - interest
      const tax  = ebt > 0 ? ebt * taxRate : 0
      const netIncome = ebt - tax
      const cashToEquity = netIncome + dep - principal
      if (equity > 0) equityPost.push(cashToEquity)
    }
    const projectFlows = [-cCapexUSD, ...cfadsBeforeDebt_tgt]
    return {
      revenueCurrent, revenueTarget, debtRows, opexSeries,
      cfadsBeforeDebt_tgt, cfadsAfterDebtSeries_tgt: cfadsBeforeDebt_tgt.map((u, i) => u - (debtRows[i]?.service || 0)),
      depreciation,
      projectIRR: irr(projectFlows),
      equityIRR: equityPre.length && hasBothSigns(equityPre) ? irr(equityPre) : NaN,
      equityIRRPostTax: equityPost.length && hasBothSigns(equityPost) ? irr(equityPost) : NaN,
      projectFlows,
      equityFlows: equityPre,
      buildYears: cBuildYears, graceYears: cGrace
    }
  }, [cTariffCurUSDm3, cTariffUSDm3, cCapexUSD, cEquityPct, cInterest, cTenor, cGrace, cBuildYears, cDepYears, cOpexUSD, inflation, taxRate, wasteYear])

  // Combined
  const combined = useMemo(() => {
    const totalCapex = aCapexUSD + bCapexUSD + cCapexUSD
    const N = Math.max(aTenor, bTenor, cTenor)
    const aU = Array.from({ length: N }, (_, i) => (i < a.cfadsBeforeDebt.length ? a.cfadsBeforeDebt[i] : 0))
    const bU = Array.from({ length: N }, (_, i) => (i < b.cfadsBeforeDebt.length ? b.cfadsBeforeDebt[i] : 0))
    const cU = Array.from({ length: N }, (_, i) => (i < c.cfadsBeforeDebt_tgt.length ? c.cfadsBeforeDebt_tgt[i] : 0))
    const totalCFADSBeforeDebtSeries = aU.map((v, i) => v + bU[i] + cU[i])
    const projectFlows = [-totalCapex, ...totalCFADSBeforeDebtSeries]
    const projectIRR = irr(projectFlows)
    const totalCFADSBeforeDebt = totalCFADSBeforeDebtSeries.reduce((p,c)=>p+c,0)
    const ROI = totalCapex > 0 ? ((totalCFADSBeforeDebt - totalCapex) / totalCapex) : Number.NaN
    const equity0 = (aCapexUSD * clamp01(aEquityPct)) + (bCapexUSD * clamp01(bEquityPct)) + (cCapexUSD * clamp01(cEquityPct))
    const equityCF = [-equity0, ...Array.from({ length: N }, (_, i) =>
      (i < a.cfadsAfterDebtSeries.length ? a.cfadsAfterDebtSeries[i] : 0) +
      (i < b.cfadsAfterDebtSeries.length ? b.cfadsAfterDebtSeries[i] : 0) +
      (i < c.cfadsAfterDebtSeries_tgt.length ? c.cfadsAfterDebtSeries_tgt[i] : 0)
    )]
    const equityIRR = hasBothSigns(equityCF) ? irr(equityCF) : NaN
    return { totalCapex, totalCFADSBeforeDebt, totalCFADSBeforeDebtSeries, projectIRR, equityIRR, ROI, N, projectFlows, equityCF }
  }, [a, b, c, aCapexUSD, bCapexUSD, cCapexUSD, aEquityPct, bEquityPct, cEquityPct, aTenor, bTenor, cTenor])

  // Datasets including build-years (investing spread)
  const DS_A = usePartDatasets(aTenor, aCapexUSD, a.buildYears, a.revenue, a.opexSeries, a.debtRows, a.cfadsBeforeDebt)
  const DS_B = usePartDatasets(bTenor, bCapexUSD, b.buildYears, b.revenue, b.opexSeries, b.debtRows, b.cfadsBeforeDebt)
  const DS_C = usePartDatasets(cTenor, cCapexUSD, c.buildYears, c.revenueTarget, c.opexSeries, c.debtRows, c.cfadsBeforeDebt_tgt)

  const DS_ALL = useCombinedDatasets(
    Math.max(aTenor, bTenor, cTenor),
    (y)=> {
      let inv = 0
      const aSlice = (a.buildYears>0) ? -(aCapexUSD/a.buildYears) : -aCapexUSD
      const bSlice = (b.buildYears>0) ? -(bCapexUSD/b.buildYears) : -bCapexUSD
      const cSlice = (c.buildYears>0) ? -(cCapexUSD/c.buildYears) : -cCapexUSD
      if (y === 0) inv += aSlice + bSlice + cSlice
      if (a.buildYears>1 && y>0 && y<a.buildYears) inv += aSlice
      if (b.buildYears>1 && y>0 && y<b.buildYears) inv += bSlice
      if (c.buildYears>1 && y>0 && y<c.buildYears) inv += cSlice
      return inv
    },
    (y)=> (y===0?0: (y<=a.buildYears+aTenor? a.revenue:0) + (y<=b.buildYears+bTenor? b.revenue:0) + (y<=c.buildYears+cTenor? c.revenueTarget:0)),
    (y)=> (y===0?0: (y> a.buildYears && (y- a.buildYears)<=aTenor? a.opexSeries[y- a.buildYears-1]||0:0) +
                   (y> b.buildYears && (y- b.buildYears)<=bTenor? b.opexSeries[y- b.buildYears-1]||0:0) +
                   (y> c.buildYears && (y- c.buildYears)<=cTenor? c.opexSeries[y- c.buildYears-1]||0:0)),
    (y)=> (y===0?0: (y> a.buildYears && (y- a.buildYears)<=aTenor? a.debtRows[y- a.buildYears-1]?.service|| 0:0) +
                   (y> b.buildYears && (y- b.buildYears)<=bTenor? b.debtRows[y- b.buildYears-1]?.service|| 0:0) +
                   (y> c.buildYears && (y- c.buildYears)<=cTenor? c.debtRows[y- c.buildYears-1]?.service|| 0:0)),
    (y)=> (y===0?0: (y> a.buildYears && (y- a.buildYears)<=aTenor? a.cfadsBeforeDebt[y- a.buildYears-1]||0:0) +
                   (y> b.buildYears && (y- b.buildYears)<=bTenor? b.cfadsBeforeDebt[y- b.buildYears-1]||0:0) +
                   (y> c.buildYears && (y- c.buildYears)<=cTenor? c.cfadsBeforeDebt_tgt[y- c.buildYears-1]||0:0)),
    Math.max(a.buildYears, b.buildYears, c.buildYears)
  )

  // Scenarios
  const [scenarioName, setScenarioName] = useState('')
  const [scenarios, setScenarios] = useState(listScenarios())
  const refreshScenarios = () => setScenarios(listScenarios())

  const snapshot = () => ({
    currency, fxUSD2MXN, discountRate, taxRate,
    occupiedRooms, roomRateUSD, splitA, inflation,
    aCapexUSD, aEquityPct, aInterest, aTenor, aGrace, aBuildYears, aDepYears, aOpexUSD,
    bCapexUSD, bEquityPct, bInterest, bTenor, bGrace, bBuildYears, bDepYears, bOpexUSD, bPowerMW, bTariffUSDkWh,
    cCapexUSD, cEquityPct, cInterest, cTenor, cGrace, cBuildYears, cDepYears, cOpexUSD, cTariffUSDm3, cTariffCurUSDm3, wasteDay
  })

  const handleSave = () => {
    const name = (scenarioName || '').trim() || 'Scenario ' + (scenarios.length+1)
    saveScenario(name, snapshot()); setScenarioName(''); refreshScenarios()
  }
  const handleLoad = (name:string) => {
    const s = loadScenario(name); if (!s) return
    const st = s.state
    setCurrency(st.currency); setFxUSD2MXN(st.fxUSD2MXN); setDiscountRate(st.discountRate); setTaxRate(st.taxRate);
    setOccupiedRooms(st.occupiedRooms); setRoomRateUSD(st.roomRateUSD); setSplitA(st.splitA); setInflation(st.inflation);
    setACapexUSD(st.aCapexUSD); setAEquityPct(st.aEquityPct); setAInterest(st.aInterest); setATenor(st.aTenor); setAGrace(st.aGrace); setABuildYears(st.aBuildYears); setADepYears(st.aDepYears); setAOpexUSD(st.aOpexUSD);
    setBCapexUSD(st.bCapexUSD); setBEquityPct(st.bEquityPct); setBInterest(st.bInterest); setBTenor(st.bTenor); setBGrace(st.bGrace); setBBuildYears(st.bBuildYears); setBDepYears(st.bDepYears); setBOpexUSD(st.bOpexUSD); setBPowerMW(st.bPowerMW); setBTariffUSDkWh(st.bTariffUSDkWh);
    setCCapexUSD(st.cCapexUSD); setCEquityPct(st.cEquityPct); setCInterest(st.cInterest); setCTenor(st.cTenor); setCGrace(st.cGrace); setCBuildYears(st.cBuildYears); setCDepYears(st.cDepYears); setCOpexUSD(st.cOpexUSD); setCTariffUSDm3(st.cTariffUSDm3); setCTariffCurUSDm3(st.cTariffCurUSDm3); setWasteDay(st.wasteDay);
  }
  const handleDelete = (name:string) => { deleteScenario(name); refreshScenarios() }

  const exportPart = (label:string, ds:any) => {
    const rows = ds.cashFlowData.map((r:any)=>({Year:r.year, Operating:r.Operating, Investing:r.Investing, Financing:r.Financing, Net:r.Net}))
    downloadCSV(label+'.csv', rows)
  }
  const exportCombined = () => exportPart('Combined', DS_ALL)

  const tone = (irr:number|undefined) => (irr!=null && !isNaN(irr) ? (irr>=0.14?'good':'bad') : undefined)

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Fixed Header */}
      <header className="fixed top-0 left-0 w-full bg-slate-800/95 backdrop-blur supports-[backdrop-filter]:bg-slate-800/75 shadow-md z-50">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center gap-3">
          <img src="/logo.png" alt="Company logo" className="h-12 w-auto" />
          <h1 className="text-2xl font-bold tracking-tight">Cancun CISEC</h1>
        </div>
      </header>

      {/* Main */}
      <main className="pt-20 px-6">
        <div className="max-w-7xl mx-auto space-y-6">

          {/* Finance toggles (currency/discount/tax/reset included) */}
          <FinanceToggles
            a={{aGrace, setAGrace, aBuildYears, setABuildYears, aDepYears, setADepYears}}
            b={{bGrace, setBGrace, bBuildYears, setBBuildYears, bDepYears, setBDepYears}}
            c={{cGrace, setCGrace, cBuildYears, setCBuildYears, cDepYears, setCDepYears}}
            currency={currency} setCurrency={setCurrency}
            fxUSD2MXN={fxUSD2MXN} setFxUSD2MXN={setFxUSD2MXN}
            discountRate={discountRate} setDiscountRate={setDiscountRate}
            taxRate={taxRate} setTaxRate={setTaxRate}
            resetAll={()=>{
              setCurrency('USD'); setFxUSD2MXN(18); setDiscountRate(0.10); setTaxRate(0.25);
              setOccupiedRooms(38000); setRoomRateUSD(1); setSplitA(0.55); setInflation(0.04);
              setACapexUSD(18_000_000); setAEquityPct(0.30); setAInterest(0.12); setATenor(10); setAGrace(0); setABuildYears(0); setADepYears(10); setAOpexUSD(1_500_000);
              setBCapexUSD(22_000_000); setBEquityPct(0.30); setBInterest(0.12); setBTenor(10); setBGrace(0); setBBuildYears(0); setBDepYears(10); setBOpexUSD(1_800_000); setBPowerMW(6); setBTariffUSDkWh(0.12);
              setCCapexUSD(54_444_444); setCEquityPct(0.30); setCInterest(0.12); setCTenor(10); setCGrace(0); setCBuildYears(0); setCDepYears(15); setCOpexUSD(3_333_333); setCTariffUSDm3(0.80); setCTariffCurUSDm3(0.083); setWasteDay(47_000);
            }}
          />

          {/* Scenarios toolbar */}
          <section className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 shadow-lg">
            <div className="flex flex-wrap items-center gap-2">
              <input className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs" placeholder="Scenario name…" value={scenarioName} onChange={(e)=>setScenarioName(e.target.value)} />
              <button onClick={handleSave} className="text-xs border border-slate-700 hover:bg-slate-800 rounded px-3 py-1">Save</button>
              <select className="bg-slate-950 border border-slate-800 rounded px-2 py-1 text-xs" onChange={(e)=>e.target.value && handleLoad(e.target.value)}>
                <option value="">Load…</option>
                {scenarios.map((s:any) => <option key={s.name} value={s.name}>{s.name}</option>)}
              </select>
              <button disabled={scenarios.length===0} onClick={()=>scenarios.length>0 && handleDelete(scenarios[scenarios.length-1].name)} className="text-xs border border-slate-700 hover:bg-slate-800 rounded px-3 py-1 disabled:opacity-50">Delete last</button>
              <div className="ml-auto flex gap-2">
                <button onClick={()=>exportPart('PartA', DS_A)} className="text-xs border border-slate-700 hover:bg-slate-800 rounded px-3 py-1">Export Part A (CSV)</button>
                <button onClick={()=>exportPart('PartB', DS_B)} className="text-xs border border-slate-700 hover:bg-slate-800 rounded px-3 py-1">Export Part B (CSV)</button>
                <button onClick={()=>exportPart('PartC', DS_C)} className="text-xs border border-slate-700 hover:bg-slate-800 rounded px-3 py-1">Export Part C (CSV)</button>
                <button onClick={exportCombined} className="text-xs border border-slate-700 hover:bg-slate-800 rounded px-3 py-1">Export Combined (CSV)</button>
              </div>
            </div>
          </section>

          {/* Common inputs */}
          <section className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 shadow-lg">
            <h2 className="font-semibold mb-3">Common Inputs – Shared A & B Revenue</h2>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-semibold">Occupied rooms (per day) <Help text="Total occupied rooms per day across the district." /></label>
                <input type="number" value={occupiedRooms} step={100} onChange={(e)=>setOccupiedRooms(parseFloat(e.target.value)||0)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-md px-2 py-1" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold">$ per occupied room per day (USD) <Help text="Average daily fee per occupied room that funds A & B." /></label>
                <input type="range" min={0} max={30} step={0.1} value={roomRateUSD} onChange={(e)=>setRoomRateUSD(parseFloat(e.target.value)||0)} className="w-full" />
                <div className="text-xs text-slate-400">Current: ${roomRateUSD.toFixed(2)} / room / day</div>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-semibold">Split allocation to Part A <Help text="Share of room fee going to Part A (rest to Part B)." /></label>
                <input type="range" min={0} max={1} step={0.01} value={splitA} onChange={(e)=>setSplitA(parseFloat(e.target.value)||0)} className="w-full" />
                <div className="text-xs text-slate-400">A: {(splitA*100).toFixed(0)}% • B: {((1-splitA)*100).toFixed(0)}%</div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <KPI title={`Gross A+B revenue (yr, ${currency})`} value={money(shared.annualGross)} help="Room fee × occupied rooms × 365." />
                <div className="space-y-1">
                  <label className="text-sm font-semibold">Inflation (OPEX escalation) <Help text="Annual growth applied to OPEX streams." /></label>
                  <input type="range" min={0} max={0.2} step={0.0025} value={inflation} onChange={(e)=>setInflation(parseFloat(e.target.value)||0)} className="w-full" />
                  <div className="text-xs text-slate-400">{(inflation*100).toFixed(2)}% / yr</div>
                </div>
              </div>
            </div>
          </section>

          {/* Parts */}
          <PartA money={money} currency={currency} onViewCharts={()=>setView('chartA')}
            S={{ aCapexUSD, setACapexUSD, aEquityPct, setAEquityPct, aOpexUSD, setAOpexUSD, aInterest, setAInterest, aTenor, setATenor }} A={a} />
          <PartB money={money} currency={currency} onViewCharts={()=>setView('chartB')}
            S={{ bCapexUSD, setBCapexUSD, bEquityPct, setBEquityPct, bOpexUSD, setBOpexUSD, bInterest, setBInterest, bTenor, setBTenor, bPowerMW, setBPowerMW, bTariffUSDkWh, setBTariffUSDkWh }} B={b} />
          <PartC money={money} currency={currency} onViewCharts={()=>setView('chartC')}
            S={{ wasteDay, setWasteDay, cCapexUSD, setCCapexUSD, cEquityPct, setCEquityPct, cOpexUSD, setCOpexUSD, cInterest, setCInterest, cTenor, setCTenor, cTariffUSDm3, setCTariffUSDm3, cTariffCurUSDm3, setCTariffCurUSDm3 }} C={c} />

          {/* Combined KPIs */}
          <section className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 shadow-lg">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold">Combined Overview</h2>
              <button onClick={()=>setView('chartAll')} className="text-xs border border-slate-700 hover:bg-slate-800 rounded-lg px-3 py-1">View combined chart →</button>
            </div>
            <div className="grid md:grid-cols-4 gap-3">
              <KPI title={`Total CAPEX (${currency})`} value={money(aCapexUSD + bCapexUSD + cCapexUSD)} help="Sum of A+B+C CAPEX." />
              <KPI title={`Total CFADS before debt (sum, ${currency})`} value={money(a.cfadsBeforeDebt.reduce((p,c)=>p+c,0)+b.cfadsBeforeDebt.reduce((p,c)=>p+c,0)+c.cfadsBeforeDebt_tgt.reduce((p,c)=>p+c,0))} help="Aggregate CFADS before debt service." />
              <KPI title="IRR (project)" value={`${isNaN(combined.projectIRR)?'—':(combined.projectIRR*100).toFixed(2)+'%'}`} help="Unlevered IRR across all parts." />
              <KPI title="IRR (equity, avg post-tax)" value={`${isNaN(((a.equityIRRPostTax+b.equityIRRPostTax+c.equityIRRPostTax)/3))?'—':(((a.equityIRRPostTax+b.equityIRRPostTax+c.equityIRRPostTax)/3)*100).toFixed(2)+'%'}`} help="Average of per-part leveraged post-tax equity IRRs." />
              <KPI title="ROI (unlevered, over horizon)" value={`${isNaN(((a.cfadsBeforeDebt.reduce((p,c)=>p+c,0)+b.cfadsBeforeDebt.reduce((p,c)=>p+c,0)+c.cfadsBeforeDebt_tgt.reduce((p,c)=>p+c,0)) - (aCapexUSD+bCapexUSD+cCapexUSD)) / (aCapexUSD+bCapexUSD+cCapexUSD))?'—':((((a.cfadsBeforeDebt.reduce((p,c)=>p+c,0)+b.cfadsBeforeDebt.reduce((p,c)=>p+c,0)+c.cfadsBeforeDebt_tgt.reduce((p,c)=>p+c,0)) - (aCapexUSD+bCapexUSD+cCapexUSD)) / (aCapexUSD+bCapexUSD+cCapexUSD))*100).toFixed(2)+'%'}`} help="(Sum unlevered CFADS − CAPEX) ÷ CAPEX." />
              <KPI title={`Project NPV @ ${(discountRate*100).toFixed(1)}% (${currency})`} value={money(npv(discountRate, [-(aCapexUSD+bCapexUSD+cCapexUSD), ...DS_ALL.cashFlowData.slice(1).map(r=>Number(r.Operating))]))} help="NPV of unlevered cash flows." />
              <KPI title="Project Payback (yrs)" value={`${isNaN(paybackYears([-(aCapexUSD+bCapexUSD+cCapexUSD), ...DS_ALL.cashFlowData.slice(1).map(r=>Number(r.Operating))]))?'—':(paybackYears([-(aCapexUSD+bCapexUSD+cCapexUSD), ...DS_ALL.cashFlowData.slice(1).map(r=>Number(r.Operating))])).toFixed(2)}`} help="Years until cumulative unlevered cash flows ≥ 0." />
            </div>
          </section>

          {/* Chart preview */}
          <section className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 shadow-lg">
            <div className="grid md:grid-cols-2 gap-4">
              <CashFlowChart data={DS_ALL.cashFlowData} label="Combined Cash Flow (with Build Investing)" money={money} thousands />
              <RevNetChart data={DS_ALL.revNetData} label="Combined Revenues & Net" money={money} thousands showCumulative />
            </div>
          </section>

        </div>
      </main>
    </div>
  )
}
